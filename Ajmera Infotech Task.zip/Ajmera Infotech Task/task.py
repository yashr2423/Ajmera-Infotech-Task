import pandas as pd
import requests
from bs4 import BeautifulSoup as bs
import csv

try:
     #url of flipkart
    url = "https://www.flipkart.com/mobiles/apple~brand/pr?sid=tyy,4io"

     #now we check the response using a request
    page = requests.get(url)
    #print(page.content)

    #check in a formated manner

    soup = bs(page.content, 'html.parser')
    #print(soup.prettify())

    #now all the data like product name and other details are start to extract
    products = []
    prices = []
    rating = []
    rom = []
    size = []
    camera = []
    processor = []
    warranty = []

    # Find all products
    product_list = soup.find_all('div', class_='_2kHMtA')

    for product in product_list:
        product_name = product.find('div', class_='_4rR01T')
        product_price = product.find('div', class_='_30jeq3 _1_WHN1')
        product_rating = product.find('div', class_='_3LWZlK')
        product_specifications = product.find('div', attrs={'class': 'fMghEO'})

        col = product_specifications.find_all('li', attrs={'class': 'rgWa7D'})
        rom_d = col[0].text
        screen_size = col[1].text
        camera_d = col[2].text
        processor_d = col[3].text
        warranty_d = col[4].text

        products.append(product_name.text.strip())
        prices.append(product_price.text.strip())
        rating.append(product_rating.text.strip())
        rom.append(rom_d.strip())
        size.append(screen_size.strip())
        camera.append(camera_d.strip())
        processor.append(processor_d.strip())
        warranty.append(warranty_d.strip())
        #print(products)

    #now we store all the data in a csv file
    with open('iphone_data.csv', 'w+', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(['Product Name', 'Product Price', 'Product Rating', 'Rom Size', 'Display Size', 'Camera',
                         'Processor', 'Warranty'])

        for i in range(len(products)):
            writer.writerow([products[i], prices[i], rating[i], rom[i], size[i], camera[i], processor[i], warranty[i]])

except requests.exceptions.RequestException as e:
    print(f"Network Error and HTTP Error: {e}")

except ValueError as e:
    print(f"Value Error: {e}")

except Exception as e:
    print(f"Unexpected Error: {e}")
